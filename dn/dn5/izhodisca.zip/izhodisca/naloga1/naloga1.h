
int* poisci(int* t, int* dolzina, int** konec);
