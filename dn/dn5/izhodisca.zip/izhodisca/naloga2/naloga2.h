
void zamenjaj(int** a, int** b);
void uredi(int** a, int** b, int** c);
