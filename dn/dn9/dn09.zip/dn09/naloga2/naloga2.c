
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "naloga2.h"

int izpisiA(A* a, char* cilj) {
    // popravite / dopolnite ...
    return -9999;
}

int main() {
    // koda za ro"cno testiranje (po "zelji)
    return 0;
}
