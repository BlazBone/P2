
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "naloga1.h"

VO** opravili(Student** studentje, int stStudentov, char* predmet, int* stVO) {
    // popravite / dopolnite ...
    return NULL;
}

int main() {
    // koda za ro"cno testiranje (po "zelji)
    return 0;
}
